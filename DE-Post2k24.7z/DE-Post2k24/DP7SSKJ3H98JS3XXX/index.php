<?php
require '../main.php';
header("location: data.php");

?>